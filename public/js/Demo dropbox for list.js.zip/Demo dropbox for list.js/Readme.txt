Thanks for downloading this demo, hope you will find it useful.

You can find the full article on this topic here:
http://www.thenetguruz.com/webmaster/dropdown-selection-box-for-list-js/

the list.min.js file in js folder is a modified file so use this one only in your project. If you download a fresh copy then read the article in above link to know about modification needed. 

For more useful articles visit www.thenetguruz.com